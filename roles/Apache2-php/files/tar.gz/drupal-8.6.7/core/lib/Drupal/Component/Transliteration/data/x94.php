<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = [
  0x00 => 'kui', 'si', 'liu', 'nao', 'huang', 'pie', 'sui', 'fan', 'qiao', 'quan', 'yang', 'tang', 'xiang', 'jue', 'jiao', 'zun',
  0x10 => 'liao', 'qie', 'lao', 'dui', 'xin', 'zan', 'ji', 'jian', 'zhong', 'deng', 'ya', 'ying', 'dui', 'jue', 'nou', 'zan',
  0x20 => 'pu', 'tie', 'fan', 'zhang', 'ding', 'shan', 'kai', 'jian', 'fei', 'sui', 'lu', 'juan', 'hui', 'yu', 'lian', 'zhuo',
  0x30 => 'qiao', 'jian', 'zhuo', 'lei', 'bi', 'tie', 'huan', 'ye', 'duo', 'guo', 'dang', 'ju', 'fen', 'da', 'bei', 'yi',
  0x40 => 'ai', 'zong', 'xun', 'diao', 'zhu', 'heng', 'zhui', 'ji', 'nie', 'he', 'huo', 'qing', 'bin', 'ying', 'kui', 'ning',
  0x50 => 'xu', 'jian', 'jian', 'qian', 'cha', 'zhi', 'mie', 'li', 'lei', 'ji', 'zuan', 'kuang', 'shang', 'peng', 'la', 'du',
  0x60 => 'shuo', 'chuo', 'lu', 'biao', 'bao', 'lu', 'xian', 'kuan', 'long', 'e', 'lu', 'xin', 'jian', 'lan', 'bo', 'jian',
  0x70 => 'yao', 'chan', 'xiang', 'jian', 'xi', 'guan', 'cang', 'nie', 'lei', 'cuan', 'qu', 'pan', 'luo', 'zuan', 'luan', 'zao',
  0x80 => 'nie', 'jue', 'tang', 'shu', 'lan', 'jin', 'ga', 'yi', 'zhen', 'ding', 'zhao', 'po', 'liao', 'tu', 'qian', 'chuan',
  0x90 => 'shan', 'ji', 'fan', 'diao', 'men', 'nu', 'yang', 'chai', 'xing', 'gai', 'bu', 'tai', 'ju', 'dun', 'chao', 'zhong',
  0xA0 => 'na', 'bei', 'gang', 'ban', 'qian', 'yao', 'qin', 'jun', 'wu', 'gou', 'kang', 'fang', 'huo', 'tou', 'niu', 'ba',
  0xB0 => 'yu', 'qian', 'zheng', 'qian', 'gu', 'bo', 'e', 'po', 'bu', 'bo', 'yue', 'zuan', 'mu', 'tan', 'jia', 'dian',
  0xC0 => 'you', 'tie', 'bo', 'ling', 'shuo', 'qian', 'mao', 'bao', 'shi', 'xuan', 'ta', 'bi', 'ni', 'pi', 'duo', 'xing',
  0xD0 => 'kao', 'lao', 'er', 'mang', 'ya', 'you', 'cheng', 'jia', 'ye', 'nao', 'zhi', 'dang', 'tong', 'lu', 'diao', 'yin',
  0xE0 => 'kai', 'zha', 'zhu', 'xi', 'ding', 'diu', 'xian', 'hua', 'quan', 'sha', 'ha', 'diao', 'ge', 'ming', 'zheng', 'se',
  0xF0 => 'jiao', 'yi', 'chan', 'chong', 'tang', 'an', 'yin', 'ru', 'zhu', 'lao', 'pu', 'wu', 'lai', 'te', 'lian', 'keng',
];
